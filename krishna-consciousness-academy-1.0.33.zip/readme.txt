== Krishna Consciousness Academy ==

Contributors: Pavel Pasechnik
Requires at least: 6.8
Tested up to: 6.8
Requires PHP: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Krishna Consciousness Academy is an inspiring WordPress theme for academies of Vaishnava philosophy, online education, and spiritual communities. Easy customization and a convenient editor allow you to quickly create a website that reflects the values and traditions of bhakti yoga.


== Changelog ==

= 1.0.0 =
* Initial release


== Copyright ==

Krishna Consciousness Academy WordPress Theme, (C) 2025 Pavel Pasechnik
Krishna Consciousness Academy is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


Krishna Consciousness Academy is based on Twenty Twenty-Five (https://wordpress.org/themes/twentytwentyfive/), (C) the WordPress team, [GPLv2 or later](http://www.gnu.org/licenses/gpl-2.0.html)

